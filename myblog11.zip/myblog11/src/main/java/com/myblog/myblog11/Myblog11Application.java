package com.myblog.myblog11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Myblog11Application {

	public static void main(String[] args) {
		SpringApplication.run(Myblog11Application.class, args);
	}

}
